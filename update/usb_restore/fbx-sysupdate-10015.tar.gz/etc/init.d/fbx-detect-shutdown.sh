#!/bin/sh
### BEGIN INIT INFO
# Provides:             fbx-detect-shutdown.sh
# Required-Start:       $ALL
# Default-Start:        2 3 4 5
# Default-Stop:         0 1 6
# Short-Description:    FlashboxX detect shutdown
# Description:          Detect a keypress of 5s and then shutdown the FlashboxX
### END INIT INFO

VERSION="1.0"
DESC="Detect a keypress of 5s and then shutdown the FlashboxX"
NAME="fbx-detect-shutdown"
PIDFILE="/var/run/$NAME.pid"
DAEMON="/usr/local/bin/fbx-detect-shutdown-daemon.pl"
DAEMON_OPTS=""

# Does the daemon exist
test -x $DAEMON || exit 0

. /lib/lsb/init-functions

case "$1" in
  start)
        log_daemon_msg "Starting "$DAEMON
        if start-stop-daemon --start --make-pidfile --pidfile $PIDFILE --background --exec $DAEMON -- $DAEMON_OPTS; then
            log_end_msg 0
        else
            log_end_msg 1
        fi
        ;;
  stop)
        log_daemon_msg "Stopping "$DAEMON
        if start-stop-daemon --stop --signal INT --pidfile $PIDFILE --remove-pidfile; then
            log_end_msg 0
        else
            log_end_msg 1
        fi
        ;;

  status)
        status_of_proc -p $PIDFILE $DAEMON && exit 0 || exit $?
        ;;

  *)
        log_action_msg "Usage: /etc/init.d/fbx-detect-shutdown.sh {start|stop|status}"
        exit 1
esac

exit 0
