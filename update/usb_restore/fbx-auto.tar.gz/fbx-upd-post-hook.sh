#!/bin/bash

USBDIR=$1
LOGFILE=$2

source fbx-lib-common.sh

if [[ -e ${USBDIR}/sysroot ]]; then
    log "# Copying files from ${USBDIR}/sysroot"
    cp -rv ${USBDIR}/sysroot/* / >>$LOGFILE 2>&1
    if [[ $? -eq 0 ]]; then
        log "# copy sysroot ok"
    else
        log "# ERROR copy ${USBDIR}/sysroot to / failed"
        exit 1
    fi
else
    log "# ${USBDIR}/sysroot no files found"
fi

hookscript=${USBDIR}/post-hook.sh

if [[ -f ${hookscript} ]]; then
    log "# Running ${hookscript}"
    bash ${hookscript} $USBDIR $LOGFILE
    if [[ $? -eq 0 ]]; then
        log "# ${hookscript} exec ok"
    else
        log "# ERROR ${hookscript} exec failed"
        exit 1
    fi
else
    log "# ${hookscript} not found"
fi

exit 0
