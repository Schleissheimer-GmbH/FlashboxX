#!/bin/bash

USBDIR=$1
LOGFILE=$2

source fbx-lib-common.sh

KERNELUP=$(find ${USBDIR} -name "fbx-kernel-*.tar.gz" -type f)

log "# Starting kernel Update"

RESULT=1

if [[ -f "$KERNELUP" ]]; then
    HWTYPE=$(GetFlashboxHW)

    KERNELTMP="/tmp/kernel_temp"

    if  [[ "$HWTYPE" != "flashboxx" ]]; then
        log "# ERROR Hardware is not a FlashboxX"
        exit 1
    fi

    log "# Extracting ${KERNELUP} to ${KERNELTMP}"

    rm -r $KERNELTMP
    mkdir -p $KERNELTMP
    tar -xvf "$KERNELUP" --no-same-owner --directory $KERNELTMP >>$LOGFILE 2>&1
    if [[ $? -eq 0 ]]; then
        log "# Kernel extract ok"

        cp $KERNELTMP/* / --recursive --verbose >>$LOGFILE 2>&1
        if [[ $? -eq 0 ]]; then
          log "# Kernel copy ok"
          RESULT=0
        else
          log "# ERROR: kernel copy failed"
        fi
        # Cleanup
        rm -r $KERNELTMP
    else
        log "# ERROR: extract failed"
    fi
else
    log "# System Update kernel-*.tar.gz in ${USBDIR} not found"
    RESULT=0
fi

exit ${RESULT}
