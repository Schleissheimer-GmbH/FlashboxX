#!/bin/bash

USBDIR=$1
LOGFILE=$2

source fbx-lib-common.sh

FLASHENVGZ=$(find ${USBDIR} -name "flashboxx_env.tar.gz" -type f)

log "# Starting FlasboxxEnv Update"

if [[ -f ${FLASHENVGZ} ]]; then
    log "# Removing old files"
    rm -r -f /flashboxx_env/ >>$LOGFILE 2>&1
    rm -r -f /ContiTools/ >>$LOGFILE 2>&1

    log "# Extracting $FLASHENVGZ"
    tar -xzvf $FLASHENVGZ -C / >>$LOGFILE 2>&1
    if [[ $? -eq 0 ]]; then
        log "# extract ${FLASHENVGZ} ok"
    else
        log "# ERROR extract ${FLASHENVGZ} failed"
        exit 1
    fi

    log "# Setting pi as owner of flashboxx_env"
    chown pi:pi /flashboxx_env -R >>$LOGFILE 2>&1

    log "# Reload all daemon configs"
    systemctl daemon-reload >>$LOGFILE 2>&1
    log "# Enable System-V style init flashbox.sh"
    update-rc.d flashbox.sh defaults >>$LOGFILE 2>&1
    log "# Check flashbox.service"
    systemctl status flashbox.service >>$LOGFILE 2>&1

else
    log "# flashboxx_env.tar.gz in ${USBDIR} not found"
fi
exit 0