#!/usr/bin/perl -w
use strict;
use warnings;

use Config;
use IO::File;
use IO::Select;

use Data::Dumper;


package Linux::Input;

# instaniate a new input device
sub new {
  my $class    = shift;
  my $filename = shift;
  my $self     = { };
  bless ($self => $class);

  $self->{fh} = IO::File->new("< $filename");
  die($!) unless ($self->{fh});

  return $self;
}

# get filehandle of device
sub fh {
  my $self = shift;
  return $self->{fh};
}

# $self's IO::Select object
sub selector {
  my $self = shift;
  unless ($self->{__io_select}) {
    $self->{__io_select} = IO::Select->new($self->fh());
  }
  return $self->{__io_select};
}

# poll for all pending events
sub poll {
  my $self     = shift;
  my $timeout  = shift || ref($self)->timeout();
  my $selector = $self->selector();
  my @ev;

  my $struct_len = 16;
  while (my ($fh) = $selector->can_read($timeout)) {
    my $buffer;
    my $len = sysread($fh, $buffer, $struct_len);
    my ($sec, $usec, $type, $code, $value) =
      unpack('L!L!S!S!i!', $buffer);
    my $event = {
      tv_sec  => $sec,
      tv_usec => $usec,
      type    => $type,
      code    => $code,
      value   => $value,
    };
    push @ev, $event if (defined($type));
  }
  return @ev;
}

package main;

print "Waiting for keypress on /dev/input/event0\n";

my $input = Linux::Input->new('/dev/input/event0');

while (1) {
  while (my @events = $input->poll(0.01)) {
    foreach my $event (@events) {
      # print Dumper ($event);

      if ($event->{type} eq 1) {
        # EV_KEY
        if ($event->{value} eq 1) {
          # Key is pressed
          print "Key " . $event->{code} . " pressed\n";
          exit 0;
        }
      }
    }
  }
}
