#!/bin/bash

FBXLEDNAMES=(
    "rgb\:fbx-led-0"
    "rgb\:fbx-led-1"
    "rgb\:fbx-led-2"
    "rgb\:fbx-led-3"
)

function log() {
    logprefix=$(date +'%d.%m.%Y %H:%M:%S : ')

    echo $logprefix $1
    if [[ -n ${LOGFILE} ]]; then
       echo ${logprefix} $1 >>${LOGFILE}
    fi
}

function waitforkeypress() {
    log "# Wait for keypress"
    perl fbx-wait-any-key.pl >>$LOGFILE 2>&1
}

function led_blink_busy() {
    for FBXLEDNAME in ${FBXLEDNAMES[@]}; do
        echo "none"    > /sys/class/leds/${FBXLEDNAME}/trigger
    done

    for FBXLEDNAME in ${FBXLEDNAMES[@]}; do
        echo 0 255 255 > /sys/class/leds/${FBXLEDNAME}/multi_intensity
        echo 50        > /sys/class/leds/${FBXLEDNAME}/brightness
        echo "timer"   > /sys/class/leds/${FBXLEDNAME}/trigger
        echo 0 255 255 > /sys/class/leds/${FBXLEDNAME}/multi_intensity
        echo 500       > /sys/class/leds/${FBXLEDNAME}/delay_on
        echo 500       > /sys/class/leds/${FBXLEDNAME}/delay_off
    done
}

function led_off() {
    for FBXLEDNAME in ${FBXLEDNAMES[@]}; do
        echo 0 > /sys/class/leds/${FBXLEDNAME}/brightness
    done
}




function exit_error() {
    for FBXLEDNAME in ${FBXLEDNAMES[@]}; do
        echo "none"  > /sys/class/leds/${FBXLEDNAME}/trigger
        echo 255 0 0 > /sys/class/leds/${FBXLEDNAME}/multi_intensity
        echo 50      > /sys/class/leds/${FBXLEDNAME}/brightness
    done

    waitforkeypress
    led_off
    shutdown -h now
    exit 1
}

function exit_ok() {
    for FBXLEDNAME in ${FBXLEDNAMES[@]}; do
        echo "none"  > /sys/class/leds/${FBXLEDNAME}/trigger
        echo 0 255 0 > /sys/class/leds/${FBXLEDNAME}/multi_intensity
        echo 50      > /sys/class/leds/${FBXLEDNAME}/brightness
    done
    waitforkeypress
    led_off
    shutdown -h now
    exit 0
}

function exit_warning() {
    for FBXLEDNAME in ${FBXLEDNAMES[@]}; do
        echo "none"    > /sys/class/leds/${FBXLEDNAME}/trigger
        echo 255 165 0 > /sys/class/leds/${FBXLEDNAME}/multi_intensity
        echo 50        > /sys/class/leds/${FBXLEDNAME}/brightness
    done
    waitforkeypress
    led_off
    shutdown -h now
    exit 0
}

function StopContiDaemon() {
    WAITTIME=0
    if [[ -f "/ContiTools/daemon.sh" ]]; then
        log "# Stopping Conti Daemon"
        /ContiTools/daemon.sh stop >>$LOGFILE 2>&1

        while true;
        do
            ALIVE=$( ps axg | grep -vw grep | grep -w Main.pl )
            if [[ "$ALIVE" == "" ]]
            then
                log "# Conti Daemon stopped"
                break;
            else
                ((WAITTIME=WAITTIME+1))
                log "# Daemon is still alive Try:$WAITTIME"
                if [[ $WAITTIME -eq 15 ]]
                then
                    log "# ERROR: Daemon stop failed"
                    break;
                fi

                # Try to stop again
                /ContiTools/daemon.sh stop >>$LOGFILE 2>&1
                sleep 1
            fi
        done
    else
        log "# No Conti Daemon found"
    fi
}

function GetFlashboxSerial() {
    # do not use $USBDIR or $LOGFILE here !!!
    local TMPID="UNKNOWN"

    if [[ -f "/etc/flashbox.xml" ]]; then
        TMPID=$(grep -oP '(?<=<SerialNumber>).*?(?=</SerialNumber>)' /etc/flashbox.xml)
    elif [[ -f "/ContiTools/Flashbox_ID.inc" ]]; then
        TMPID=$(awk -F "=" '/FLASHBOX_ID/ {print $2}' /ContiTools/Flashbox_ID.inc)
    fi

    if [[ ${TMPID} == "" ]]; then
        TMPID="ERROR"
    fi

    echo ${TMPID}
}

function GetFlashboxHW() {
    # do not use $USBDIR or $LOGFILE here !!!
    local FBTYPE="UNKNOWN"

    uname -a | grep -q "FlashboxX"
    if [[ $? -eq 0 ]]; then
        FBTYPE="flashboxx"
    else
        uname -a | grep -q "beaglebone"
        if [[ $? -eq 0 ]]; then
            FBTYPE="beaglebone"
        fi
    fi

    echo $FBTYPE
}


function ReplacePatternInFile() {
    searchpattern=$1
    replacepattern=$2
    replacefile=$3
    # log "# Comment out >$replacepattern< in >$replacefile<"
    if [[ -e $replacefile ]]; then
        grep -q "$searchpattern" $replacefile
        if [[ $? -eq 0 ]]; then
            sed -i -e "s/$searchpattern/$replacepattern/g" $replacefile
            if [[ $? -eq 0 ]]; then
                log "# Replaced >$searchpattern< with >$replacepattern< in >$replacefile<"
            else
                log "# Error Replacing >$searchpattern< in >$replacefile<"
            fi
        else
            log "# Error Pattern >$replacepattern< does not exist in >$replacefile<"
        fi
    else
        log "# Error file >$replacefile< does not exist"
    fi
}

function DeleteFile() {
    filetodelete=$1

    if [[ -f $filetodelete ]]; then
        log "# removing >$filetodelete<"
        rm $filetodelete >>$LOGFILE 2>&1
        if [[ $? -eq 0 ]]; then
            log "# removed  >$filetodelete<"
        else
            log "# ERROR cannot delete file >$filetodelete<"
        fi
    else
        log "# file >$filetodelete< not found for deletion"
    fi
}
