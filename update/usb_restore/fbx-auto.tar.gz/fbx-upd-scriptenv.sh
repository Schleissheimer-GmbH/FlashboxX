#!/bin/bash

USBDIR=$1
LOGFILE=$2

source fbx-lib-common.sh

CONTIENVGZ=$(find ${USBDIR} -name "Flashbox_Conti_*.tar.gz" -type f)

log "# Starting ScriptEnv Update"

if [[ -f ${CONTIENVGZ} ]]; then
    log "# Removing old ContiTools"
    rm -r -f /ContiTools/ >>$LOGFILE 2>&1

    log "# Extracting $CONTIENVGZ"
    tar -xzvf $CONTIENVGZ -C / >>$LOGFILE 2>&1
    if [[ $? -eq 0 ]]; then
        log "# extract ${CONTIENVGZ} ok"
    else
        log "# ERROR extract ${CONTIENVGZ} failed"
        exit 1
    fi

    ENVIRONMENT_EXIST=$(grep CONTITOOLS_DIRECTORY /etc/environment)
    if [[ -z $ENVIRONMENT_EXIST && -f "/ContiTools/data/environment.template" ]]; then
        log "# Restoring environment from template, CONTITOOLS_DIRECTORY not found"
        cp /ContiTools/data/environment.template /etc/environment >>$LOGFILE 2>&1
    fi

    if [[ ! -f /etc/profile.d/flashbox_env.sh ]]; then
        log "# Restoring flashbox_env.sh from template"
        cp /ContiTools/data/flashbox_env.sh.template /etc/profile.d/flashbox_env.sh >>$LOGFILE 2>&1
    fi

    if [[ ! -e /var/log/ContiTools ]]; then
        log "# Creating /var/log/ContiTools"
        mkdir -p /var/log/ContiTools >>$LOGFILE 2>&1
    fi

    log "# Setting pi as owner for ContiTools"
    chown pi:pi /ContiTools -R >>$LOGFILE 2>&1

    log "# Reload all daemon configs"
    systemctl daemon-reload >>$LOGFILE 2>&1
    log "# Enable System-V style init flashbox.sh"
    update-rc.d flashbox.sh defaults >>$LOGFILE 2>&1
    log "# Check flashbox.service"
    systemctl status flashbox.service >>$LOGFILE 2>&1

    log "# Running /ContiTools/sysCheck.sh"

    chmod +x /etc/profile.d/flashbox_env.sh
    source /etc/profile.d/flashbox_env.sh

    source /etc/environment

    if [[ ! -n $CONTITOOLS_DIRECTORY ]]; then
        log "# ERROR environment variable CONTITOOLS_DIRECTORY is missing"
    fi

    if [[ ! -n $PERL5LIB ]]; then
        log "# ERROR environment variable PERL5LIB is missing"
    fi

    chmod +x /ContiTools/sysCheck.sh
    /ContiTools/sysCheck.sh -n >>$LOGFILE 2>&1
    if [[ $? -eq 0 ]]; then
        log "# sysCheck.sh ok"
    else
        log "# ERROR sysCheck.sh failed"
    fi
else
    log "# ContiEnv Flashbox_Conti_*.tar.gz in ${USBDIR} not found"
fi
exit 0
