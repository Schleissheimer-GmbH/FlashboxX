#!/bin/bash

USBDIR=$1
LOGFILE=$2

source fbx-lib-common.sh

StopContiDaemon
led_blink_busy

hookscript=${USBDIR}/pre-hook.sh

if [[ -f ${hookscript} ]]; then
    log "# Running ${hookscript}"
    bash ${hookscript} $USBDIR $LOGFILE
    if [[ $? -eq 0 ]]; then
        log "# ${hookscript} exec ok"
    else
        log "# ERROR ${hookscript} exec failed"
        exit 1
    fi
else
    log "# ${hookscript} not found"
fi

exit 0
