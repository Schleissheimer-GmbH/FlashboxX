#!/bin/bash

USBDIR=$1
LOGFILE=$2

source fbx-lib-common.sh

SYSUPTARGZ=$(find ${USBDIR} -name "fbx-sysupdate-*.tar.gz" -type f)

log "# Starting System Update"

if [[ -f ${SYSUPTARGZ} ]]; then

    HWTYPE=$(GetFlashboxHW)
    if  [[ "$HWTYPE" != "flashboxx" ]]; then
        log "# ERROR Hardware is not a FlashboxX"
        exit 1
    fi

    # *** remove old network interface config
    DeleteFile "/etc/network/interfaces.d/broadr"
    DeleteFile "/etc/network/interfaces.d/canfd"

    # Binaries are now part of ScriptEnv
    DeleteFile "/usr/local/bin/isotpsendrecv"
    DeleteFile "/usr/local/bin/doipsendrecv"
    DeleteFile "/usr/local/bin/80126_Flasher"

    # *** try to create a /etc/flashbox.xml file
    if [[ -f /etc/flashbox.xml ]]; then
        log "# Found /etc/flashbox.xml"
        DeleteFile "/ContiTools/Flashbox_ID.inc"
        DeleteFile "/etc/Flashbox_ID.inc"
        DeleteFile "/etc/flashbox.inc"
    elif [[ -f /ContiTools/Flashbox_ID.inc ]]; then
        log "# Found /ContiTools/Flashbox_ID.inc"
        source /ContiTools/Flashbox_ID.inc
        if [[ -n "$FLASHBOX_ID" ]]; then
            log "# Create /etc/flashbox.xml with Serial $FLASHBOX_ID"
            cat >/etc/flashbox.xml <<EOF
<?xml version="1.0" encoding="utf-8"?>
<FlashboxConfig Version="1.0">
  <Type>FlashboxX_Eco</Type>
  <SerialNumber>$FLASHBOX_ID</SerialNumber>
  <ProductionDate>2000-01-01</ProductionDate>
  <TesterSerialNumber>$FLASHBOX_ID</TesterSerialNumber>
</FlashboxConfig>
EOF
            # Remove old file
            DeleteFile "/ContiTools/Flashbox_ID.inc"
            DeleteFile "/etc/Flashbox_ID.inc"
            DeleteFile "/etc/flashbox.inc"
        else
            log "# ERROR: Could not find FLASHBOX_ID in /ContiTools/Flashbox_ID.inc"
        fi
    else
        log "# ERROR: Could not find /ContiTools/Flashbox_ID.inc or /etc/flashbox.xml"
    fi

    # *** mount usb sticks without sync
    ReplacePatternInFile \
        'MOUNTOPTIONS="sync,noexec,nodev,noatime,nodiratime"' \
        'MOUNTOPTIONS="noexec,nodev,noatime,nodiratime"' \
        '/etc/usbmount/usbmount.conf'

    # *** extract new system files
    log "# Extracting $SYSUPTARGZ"
    tar -xzvf ${SYSUPTARGZ} -C / >>$LOGFILE 2>&1
    if [[ $? -eq 0 ]]; then
        log "# extract ${SYSUPTARGZ} ok"
    else
        log "# ERROR extract ${SYSUPTARGZ} failed"
        exit 1
    fi

    log "# Disable auto update services..."
    systemctl stop apt-daily.service apt-daily-upgrade.service >>$LOGFILE 2>&1
    systemctl stop apt-daily.timer apt-daily-upgrade.timer >>$LOGFILE 2>&1
    systemctl mask apt-daily.service apt-daily-upgrade.service >>$LOGFILE 2>&1
    systemctl disable apt-daily.service apt-daily-upgrade.service >>$LOGFILE 2>&1
    systemctl disable apt-daily.timer apt-daily-upgrade.timer >>$LOGFILE 2>&1
    systemctl kill --kill-who=all apt-daily.service >>$LOGFILE 2>&1
    sleep 3

    # Installing missing modules
    DEBFILES="/tmp/*.deb"
    for debpackage in $DEBFILES
    do
        log "# Installing ${debpackage}..."
        apt install $debpackage -o APT::Install::Error-Mode=any >>$LOGFILE 2>&1
        if [[ $? -eq 0 ]]; then
            log "# install ${debpackage} ok"
        else
            log "# ERROR install ${debpackage} failed"
            log "# Running apt processes:"
            ps aux | grep -i apt >>$LOGFILE 2>&1
            exit 1
        fi

        DeleteFile $debpackage
    done

    log "# Reload all daemon configs"
    systemctl daemon-reload >>$LOGFILE 2>&1
    log "# Enable System-V style init fbx-detect-shutdown.sh"
    update-rc.d fbx-detect-shutdown.sh defaults >>$LOGFILE 2>&1
    log "# Check fbx-detect-shutdown.service"
    systemctl status fbx-detect-shutdown.service >>$LOGFILE 2>&1
else
    log "# System Update fbx-sysupdate-*.tar.gz in ${USBDIR} not found"
fi

exit 0
