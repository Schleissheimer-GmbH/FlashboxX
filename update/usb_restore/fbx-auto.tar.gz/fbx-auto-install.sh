#!/bin/bash

# Set USB dir
USBDIR=$1

if [[ ! -d "${USBDIR}" ]]; then
   logger "fbx-auto-install: ERROR usb dir ${USBDIR} does not exist"
   exit_error
fi

source fbx-lib-common.sh

# These two Functions do not use $USBDIR or $LOGFILE
FLASHBOXHW=$(GetFlashboxHW)
FLASHBOXSERIAL=$(GetFlashboxSerial)

# Set logfile
dateprefix=$(date +'%Y-%m-%d_%H-%M-%S')
LOGFILE="${USBDIR}/fbx-auto-${FLASHBOXSERIAL}-${dateprefix}.log"

BASHSCRIPTS=(
   # Bash Scripts in the order they get executed
   "fbx-upd-pre-hook.sh"
   "fbx-upd-kernel.sh"
   "fbx-upd-sysupdate.sh"
   "fbx-upd-scriptenv.sh"
   "fbx-upd-flashenv.sh"
   "fbx-upd-app.sh"
   "fbx-upd-post-hook.sh"
)

log "##########################"
log "# Starting fbx-auto-install.sh"
log "# Logfile : ${LOGFILE}"
log "# Usbdir  : ${USBDIR}"
log "# Hardware: ${FLASHBOXHW}"
log "# Serial  : ${FLASHBOXSERIAL}"

log "##########################"
if [[ -f "${USBDIR}/fbx-upd-app.sh" ]]; then
  log "# Copy ${USBDIR}/fbx-upd-app.sh"
  cp "${USBDIR}/fbx-upd-app.sh" .
  chmod +x "fbx-upd-app.sh"  
else  
  log "# ${USBDIR}/fbx-upd-app.sh not found"
fi

SCRIPTRESULT=0

for BASHSCRIPT in ${BASHSCRIPTS[@]}; do
   if [[ -f "./${BASHSCRIPT}" ]]; then
      log "##########################"
      log "# Running ./${BASHSCRIPT}"
      sudo -E bash "./${BASHSCRIPT}" ${USBDIR} ${LOGFILE}
      if [[ $? -eq 0 ]]; then
         log "# ${BASHSCRIPT} ${USBDIR} ${LOGFILE} exec ok"
      else
         log "# ERROR ${BASHSCRIPT} ${USBDIR} ${LOGFILE} failed"
         SCRIPTRESULT=1
         break
      fi
   fi
done

sync
sleep 1

if [[ ${SCRIPTRESULT} -eq 0 ]]; then
    log "# Finished fbx-auto-install.sh ok"
    exit_ok
else
    log "# Finished fbx-auto-install.sh with errors"
    exit_error
fi

exit 0
