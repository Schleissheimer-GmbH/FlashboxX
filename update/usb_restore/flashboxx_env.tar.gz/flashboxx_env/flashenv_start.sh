#!/bin/bash

# set -o errexit   # abort on nonzero exitstatus
set -o nounset   # abort on unbound variable
set -o pipefail  # don't hide errors within pipes

LOGFILE=/var/log/flashboxx_env/init.log

log() {
    echo $1
    echo $1 >>"$LOGFILE"
}

if [ "$EUID" -ne 0 ]; then
    log "Error: You must be root do run this script"
    exit
fi

init_port() {   
    
    log "Init network port$1"    

    ip netns add port$1
    if [ $? -eq 0 ]; then
        log "Port $1: Created successfully"
    else
        log "Port $1: Error creating port ($?)"
        exit 1
    fi

    ip link set dev canfd$1 netns port$1 alias canfd
    if [ $? -eq 0 ]; then
        log "Port $1: canfd link created successfully"
    else
        log "Port $1: Error creating canfd link ($?)"
        exit 2
    fi

    ip link set dev broadr$1 netns port$1 alias broadr
    if [ $? -eq 0 ]; then
        log "Port $1: broadr link created successfully"
    else
        log "Port $1 : Error creating broadr link ($?)"
        exit 2
    fi
}

wait_for_device() {
    timeout 10s bash -c "until ip a s dev $1; do sleep 1; done" >>$LOGFILE
}

mkdir -p "/var/log/flashboxx_env"

log "----------------------------------------------------"

startdate=$(date +'%Y-%m-%d %H:%M:%S')
log "$startdate"

# Kill flash process
log "Kill already running flash processes"
killall flashenv_do_flash.sh || true

log "Wait for devices"
wait_for_device "broadr0"
wait_for_device "broadr1"
wait_for_device "canfd0"
wait_for_device "canfd1"

log "Init network namespaces"
init_port "0"
init_port "1"

# log "Start flashenv_do_flash.sh for port 0 in background"
ip netns exec port0 /flashboxx_env/flashenv_do_flash.sh -p 0 &

# log "Start flashenv_do_flash.sh for port 1 and wait"
ip netns exec port1 /flashboxx_env/flashenv_do_flash.sh -p 1

log "Finished flashing"
