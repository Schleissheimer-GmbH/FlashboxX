#!/usr/bin/python3

import socket
import time
import sys

DEST_IP = "ff14::5"
DEST_PORT = 42557

SRC_IP = "fd53:7cb8:383:2::58"
#SRC_IP = "::"
SRC_PORT = 42994
NM_MESSAGE = b"\x20\x57\x0c\x00\x00\x00\x00\x08\x10\x00\x00\x00\x00\x00\x00\x00"
ETH_PORT="broadr0.2"

if len(sys.argv) > 1:
    ETH_PORT = sys.argv[1]

print(f"Start sending on {ETH_PORT}")

tryConnect = True

while True:

    while tryConnect:
        try:
            sock = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM)
            sock.bind((SRC_IP, SRC_PORT))
            # Force sending on device with VLAN 2
            sock.setsockopt(socket.SOL_SOCKET, 25, str(ETH_PORT + '\0').encode('utf-8'))
            tryConnect = False
            break
        except Exception as e:
            print("Connection failed: " + str(e))
            time.sleep(2)
    
    try:
        sock.sendto(NM_MESSAGE, (DEST_IP, DEST_PORT))
        time.sleep(0.2)
    except Exception as e:
        print("Send failed, try reconnect: " + str(e))
        tryConnect = True
    
