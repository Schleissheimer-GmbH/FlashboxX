#!/bin/bash

# set -o errexit   # abort on nonzero exitstatus
set -o nounset   # abort on unbound variable
set -o pipefail  # don't hide errors within pipes

if [ "$EUID" -ne 0 ]; then
  echo "ERROR: you must be root do run this script"
  exit
fi

# Kill running processes
killall flashenv_do_flash.sh || true
killall flashenv_send_nm.py || true
killall cangen || true
killall 80126_Flasher || true
killall doipsendrecv || true
killall isotpsendrecv || true

# Deinit network namspaces
ip netns exec port0 ip link set dev canfd0 netns 1
ip netns exec port1 ip link set dev canfd1 netns 1
ip netns exec port0 ip link set dev broadr0 netns 1
ip netns exec port1 ip link set dev broadr1 netns 1

ip netns delete port0
ip netns delete port1

# Turn off power
fbx-switch-power0.sh off
fbx-switch-power1.sh off

# Turn off LEDs
fbx-switch-led-0.sh off
fbx-switch-led-1.sh off

echo "Deinit finished"
