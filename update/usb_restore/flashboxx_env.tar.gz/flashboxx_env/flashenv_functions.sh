#!/bin/bash

# set -o errexit   # abort on nonzero exitstatus
set -o nounset   # abort on unbound variable
set -o pipefail  # don't hide errors within pipes

function log() {
  date=$(date +'%Y-%m-%d %H:%M:%S')
  logprefix="$date : [INF    ] [SCRIPT] "
  echo "$logprefix $1"
  if [ -n $LOGFILE ]; then
    echo "$logprefix $1" >>$LOGFILE
  fi
}

function can_send_uds() {
  log "TX: $*"
  IFS=' ' read -r -a OUTPUT <<<"$(echo $* | ${ROOT_DIR}/tools/isotpsendrecv -s $CANTXID -d $CANRXID -p AA:AA -L 16:8:0 -P l -T 400:5000 $CANIFNAME)"
  local len=${#OUTPUT[@]}
  if [[ $len > 0 ]]; then
    local resp=""
    for ((i = 0; i < $len; i++)); do
      resp=$resp$(echo -e "${OUTPUT[$i]} ")
    done
    log "RX: $resp ($len)"
  else
    log "ERROR: No Data Received"
  fi
}

function doip_send_uds() {
  log "TX: $*"
  IFS=' ' read -r -a OUTPUT <<<"$(echo $* | ${ROOT_DIR}/tools/doipsendrecv --source_address $DOIPSA --target_address $DOIPTA --target_ip $DOIPTIP)"
  local len=${#OUTPUT[@]}
  if [[ $len > 0 ]]; then
    local resp=""
    for ((i = 0; i < $len; i++)); do
      resp=$resp$(echo -e "${OUTPUT[$i]} ")
    done
    log "RX: $resp ($len)"
  else
    log "ERROR: No Data Received"
  fi
}

function doip_send_uds_no_output() {
  IFS=' ' read -r -a OUTPUT <<<"$(echo $* | ${ROOT_DIR}/tools/doipsendrecv --source_address $DOIPSA --target_address $DOIPTA --target_ip $DOIPTIP)"
}

function waitforkeypress() {
  # Wait for a raw keypress
  hexdump -n 64 /dev/input/event0 >/dev/null
}
